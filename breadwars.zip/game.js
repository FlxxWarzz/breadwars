const config = {
    type: Phaser.AUTO,
    width: window.innerWidth,
    height: window.innerHeight,
    scene: {
        preload: preload,
        create: create,
        update: update
    },
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0 },
            debug: false
        }
    },
    scale: {
        mode: Phaser.Scale.RESIZE,
        autoCenter: Phaser.Scale.CENTER_BOTH
    }
};

const game = new Phaser.Game(config);

let player;
let cursors;
let keys;
let fireballs;
let playerSpeed = 5;
let fireballSpeed = 400;

function preload() {
    console.log("Starting asset loading...");

    // Try using relative path or absolute URL to confirm the fireball path
    const assetPath = 'assets/fireball.png'; // Relative path
    this.load.image('fireball', assetPath); 

    // Debugging the load process
    this.load.on('filecomplete', (key, type, data) => {
        if (key === 'fireball') {
            console.log("Fireball texture loaded successfully!");
        }
    });

    this.load.on('fileerror', (key, type, data) => {
        if (key === 'fireball') {
            console.error("Failed to load fireball texture.");
        }
    });
}

function create() {
    this.cameras.main.setBackgroundColor('#23D70A');
    player = this.add.rectangle(400, 300, 50, 50, 0x0000ff);
    this.physics.world.enable(player);
    cursors = this.input.keyboard.createCursorKeys();
    keys = {
        W: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W),
        A: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A),
        S: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S),
        D: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D)
    };
    fireballs = this.physics.add.group();
    this.input.on('pointerdown', fireWeapon, this);

    console.log("Game created.");
}

function update() {
    playerMovement();
    fireballs.getChildren().forEach(fireball => fireball.update());
}

function playerMovement() {
    let moveX = 0;
    let moveY = 0;

    if (cursors.left.isDown || keys.A.isDown) {
        moveX = -playerSpeed;
    } else if (cursors.right.isDown || keys.D.isDown) {
        moveX = playerSpeed;
    }

    if (cursors.up.isDown || keys.W.isDown) {
        moveY = -playerSpeed;
    } else if (cursors.down.isDown || keys.S.isDown) {
        moveY = playerSpeed;
    }

    let magnitude = Math.sqrt(moveX * moveX + moveY * moveY);

    if (magnitude !== 0) {
        moveX /= magnitude;
        moveY /= magnitude;
    }

    player.x += moveX * playerSpeed;
    player.y += moveY * playerSpeed;

    player.x = Phaser.Math.Clamp(player.x, 0, config.width - 50);
    player.y = Phaser.Math.Clamp(player.y, 0, config.height - 50);

    if (moveX !== 0 || moveY !== 0) {
        let angle = Math.atan2(moveY, moveX);
        player.setRotation(angle);
    }
}

function fireWeapon(pointer) {
    let direction = new Phaser.Math.Vector2(pointer.x - player.x, pointer.y - player.y).normalize();
    let fireball = new Fireball(this, player.x, player.y, direction);
    fireballs.add(fireball.sprite);
}

class Fireball {
    constructor(scene, x, y, direction) {
        this.scene = scene;
        this.sprite = this.scene.add.sprite(x, y, 'fireball');
        this.scene.physics.world.enable(this.sprite);
        this.sprite.setCollideWorldBounds(true);
        this.sprite.setBounce(0);

        let angle = Math.atan2(direction.y, direction.x);
        this.sprite.setRotation(angle);

        this.sprite.body.setVelocity(direction.x * fireballSpeed, direction.y * fireballSpeed);
    }

    update() {
        if (this.sprite.x < 0 || this.sprite.x > this.scene.game.config.width ||
            this.sprite.y < 0 || this.sprite.y > this.scene.game.config.height) {
            this.sprite.destroy();
        }
    }
}
