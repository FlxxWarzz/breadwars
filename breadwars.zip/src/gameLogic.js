import Player from './player.js';
import Fireball from './weapons.js';

let player;
let cursors;
let fireballs = [];

function create() {
    this.cameras.main.backgroundColor.setTo(0x004d00);
    player = new Player(this, 400, 300);
    cursors = this.input.keyboard.createCursorKeys();
    this.input.keyboard.on('keydown-SPACE', fireWeapon, this);
}

function update() {
    player.move(cursors);
    fireballs.forEach(fireball => fireball.update());
}

function fireWeapon() {
    let fireball = new Fireball(this, player.sprite.x, player.sprite.y, player.direction);
    fireballs.push(fireball);
}

export { create, update };
