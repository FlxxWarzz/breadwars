class Block {
    constructor(scene, x, y) {
        this.scene = scene;
        this.sprite = this.scene.add.rectangle(x, y, 50, 50, 0x808080);
    }
}

export default Block;
