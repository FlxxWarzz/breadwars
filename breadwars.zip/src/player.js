class Player {
    constructor(scene, x, y) {
        this.scene = scene;
        this.sprite = this.scene.add.rectangle(x, y, 50, 50, 0x0000ff);
        this.direction = "right";  
    }

    move(cursors) {
        let moveX = 0;
        let moveY = 0;

        if (cursors.left.isDown) {
            moveX = -5;
            this.direction = "left";
        } else if (cursors.right.isDown) {
            moveX = 5;
            this.direction = "right";
        }

        if (cursors.up.isDown) {
            moveY = -5;
            this.direction = "up";
        } else if (cursors.down.isDown) {
            moveY = 5;
            this.direction = "down";
        }

        this.sprite.x += moveX;
        this.sprite.y += moveY;

        this.sprite.x = Phaser.Math.Clamp(this.sprite.x, 0, this.scene.game.config.width - 50);
        this.sprite.y = Phaser.Math.Clamp(this.sprite.y, 0, this.scene.game.config.height - 50);
    }
}

export default Player;
