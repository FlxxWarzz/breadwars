class Fireball {
    constructor(scene, x, y, direction) {
        this.scene = scene;
        this.sprite = this.scene.add.sprite(x, y, 'fireball');
        this.scene.physics.world.enable(this.sprite);

        this.sprite.setCollideWorldBounds(true);
        this.sprite.setBounce(0);

        let velocityX = 0;
        let velocityY = 0;

        if (direction === 'left') {
            velocityX = -400;
        } else if (direction === 'right') {
            velocityX = 400;
        } else if (direction === 'up') {
            velocityY = -400;
        } else if (direction === 'down') {
            velocityY = 400;
        }

        this.sprite.body.setVelocity(velocityX, velocityY);
    }

    update() {
        if (this.sprite.x < 0 || this.sprite.x > this.scene.game.config.width ||
            this.sprite.y < 0 || this.sprite.y > this.scene.game.config.height) {
            this.sprite.destroy();
        }
    }
}

export default Fireball;
